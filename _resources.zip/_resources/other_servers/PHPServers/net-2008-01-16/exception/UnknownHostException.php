<?php
class UnknownHostException extends Exception {
	
	public function __construct($msg) {
		parent::__construct($msg);
	}
}
?>
